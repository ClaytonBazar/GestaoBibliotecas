/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Livro;

import java.util.ArrayList;

public class EmprestimoLivro {

    private int numEmprestimo;
    ArrayList<Livros> livrosEmprestados = new ArrayList<>();
    ArrayList<Livros> livrosDisponiveis = new ArrayList<>();

    public void emprestimoLivro(String titulo) {

    }

}
